﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp28
{
    internal class Program2
    {
        static void Main(string[] args)
        {
            car Ford = new car();
            Ford.model = "Mustang";
            Ford.color = "red";
            Ford.year = 2005;
            Ford.fullthrottle();

            car Opel = new car();
            Opel.model = "Astra";
            Opel.color = "black";
            Opel.year = 2010;
            Opel.fullthrottle();

            Console.WriteLine(Ford.model);
            Console.WriteLine(Opel.color);
            Console.WriteLine(Ford.year);

        }
    }
}
