﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp28
{
    internal class car
    {
        public string model;
        public string color;
        public int year;
        public void fullthrottle()
        {
            Console.WriteLine("The car is going as fast as it can!");
        }
    }
}
